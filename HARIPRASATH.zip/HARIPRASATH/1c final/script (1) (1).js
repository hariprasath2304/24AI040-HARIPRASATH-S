document.addEventListener('DOMContentLoaded', () => {
    const promptInput = document.getElementById('promptInput');
    const generateBtn = document.getElementById('generateBtn');
    const resultImage = document.getElementById('resultImage');
    const imageContainer = document.getElementById('imageContainer');
    const loadingOverlay = document.getElementById('loadingOverlay');
    const placeholderContent = document.querySelector('.placeholder-content');
    const btnText = document.querySelector('.btn-text');
    const btnLoader = document.querySelector('.btn-loader');
    const errorMessage = document.getElementById('errorMessage');
    const imageActions = document.getElementById('imageActions');
    const downloadBtn = document.getElementById('downloadBtn');
    const deleteBtn = document.getElementById('deleteBtn');
    const micBtn = document.getElementById('micBtn');

    // Hugging Face API Configuration
    const API_TOKEN = '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';
    const MODEL_URL = 'https://router.huggingface.co/hf-inference/models/black-forest-labs/FLUX.1-schnell';

    let currentImageUrl = null;

    // Helper functions
    const setLoadingState = (isLoading) => {
        if (isLoading) {
            generateBtn.disabled = true;
            btnText.textContent = 'Generating...';
            btnLoader.style.display = 'block';
            
            loadingOverlay.style.display = 'flex';
            placeholderContent.style.display = 'none';
            resultImage.style.display = 'none';
            errorMessage.style.display = 'none';
            imageContainer.classList.remove('empty');
        } else {
            generateBtn.disabled = false;
            btnText.textContent = 'Generate Image';
            btnLoader.style.display = 'none';
            loadingOverlay.style.display = 'none';
        }
    };

    const showError = (message) => {
        errorMessage.textContent = message;
        errorMessage.style.display = 'block';
        
        // Reset container visualization
        if (!currentImageUrl) {
            imageContainer.classList.add('empty');
            placeholderContent.style.display = 'flex';
        } else {
            resultImage.style.display = 'block';
        }
    };

    // Generating logic
    const generateImage = async () => {
        const prompt = promptInput.value.trim();
        
        if (!prompt) {
            showError('Please enter a description for your image first.');
            promptInput.focus();
            return;
        }

        setLoadingState(true);

        try {
            const response = await fetch(MODEL_URL, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${API_TOKEN}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ inputs: prompt })
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                console.error("API Error Response:", errorData);
                throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
            }

            const blob = await response.blob();
            
            // Validate the blob is actually an image
            if (!blob.type.startsWith('image/')) {
                 throw new Error("API returned unexpected data form instead of image.");
            }

            // Cleanup prev image url if it exists to avoid memory leaks
            if (currentImageUrl) {
                URL.revokeObjectURL(currentImageUrl);
            }

            currentImageUrl = URL.createObjectURL(blob);
            
            // Set image and reveal
            resultImage.src = currentImageUrl;
            resultImage.style.display = 'block';
            imageActions.style.display = 'flex';
            
            // Adding a small delay just to ensure the image is loaded into the DOM before fading it in
            resultImage.onload = () => {
                setLoadingState(false);
            };

        } catch (error) {
            console.error('Error generating image:', error);
            setLoadingState(false);
            showError(`Failed to generate image: ${error.message}. Wait a moment, model might be loading.`);
        }
    };

    // Download functionality
    downloadBtn.addEventListener('click', () => {
        if (!currentImageUrl) return;
        
        const a = document.createElement('a');
        a.href = currentImageUrl;
        // Suggest a filename based on prompt or default
        const safePromptName = promptInput.value.substring(0, 20).replace(/[^a-z0-9]/gi, '_').toLowerCase() || 'generated';
        a.download = `flux_${safePromptName}.png`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    });

    // Delete functionality
    deleteBtn.addEventListener('click', () => {
        if (!currentImageUrl) return;
        
        // Revoke the object URL to free memory
        URL.revokeObjectURL(currentImageUrl);
        currentImageUrl = null;
        
        // Reset the UI to empty state
        resultImage.src = '';
        resultImage.style.display = 'none';
        imageActions.style.display = 'none';
        imageContainer.classList.add('empty');
        placeholderContent.style.display = 'flex';
        promptInput.value = ''; // clear the prompt as well
    });

    // Speech to Text functionality
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    let recognition = null;
    let isRecording = false;

    if (SpeechRecognition) {
        recognition = new SpeechRecognition();
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.lang = 'en-US';

        let startText = ""; // To keep the text that was already in the input before we started recording

        recognition.onstart = () => {
            isRecording = true;
            micBtn.classList.add('recording');
            startText = promptInput.value;
            promptInput.placeholder = "Listening...";
        };

        recognition.onresult = (event) => {
            let interimTranscript = '';
            for (let i = event.resultIndex; i < event.results.length; ++i) {
                if (event.results[i].isFinal) {
                    startText += event.results[i][0].transcript + ' ';
                } else {
                    interimTranscript += event.results[i][0].transcript;
                }
            }
            promptInput.value = startText + interimTranscript;
        };

        recognition.onerror = (event) => {
            console.error('Speech recognition error', event.error);
            isRecording = false;
            micBtn.classList.remove('recording');
            promptInput.placeholder = "Describe the image you want to create... e.g. A futuristic city glowing in neon under a cyberpunk sky";
            if (event.error !== 'no-speech') {
                showError('Microphone error: ' + event.error);
            }
        };

        recognition.onend = () => {
            isRecording = false;
            micBtn.classList.remove('recording');
            promptInput.placeholder = "Describe the image you want to create... e.g. A futuristic city glowing in neon under a cyberpunk sky";
        };

        micBtn.addEventListener('click', () => {
            if (isRecording) {
                recognition.stop();
            } else {
                recognition.start();
            }
        });
    } else {
        micBtn.style.display = 'none';
        console.warn("Web Speech API is not supported by this browser.");
    }

    // Submitting via "Ctrl + Enter"
    promptInput.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
            generateImage();
        }
    });

    generateBtn.addEventListener('click', generateImage);
});
